
import React, { useState } from 'react';
import { Spinner } from './Spinner';

interface InputFormProps {
  onAnalyze: (text: string) => void;
  isLoading: boolean;
}

const LightbulbIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M12 2C8.69 2 6 4.69 6 8c0 2.5 1.44 4.63 3.5 5.61V16c0 .55.45 1 1 1h3c.55 0 1-.45 1-1v-2.39C16.56 12.63 18 10.5 18 8c0-3.31-2.69-6-6-6zm0 10.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5zM9.5 18v1h5v-1h-5zM8 20v1h8v-1H8z"/>
    </svg>
);


const sampleReferral = "New referral from St. Joseph's hospital. Patient is John Smith, needs skilled nursing and PT. He lives in Anytown, 90210. His daughter Jane Doe is the main contact. The referral was given by Sarah at the hospital.";
const sampleActivity = "Just left Dr. Adams' office at Springfield General. Dropped in to give them some new brochures. It went well, he said they have a few patients who might need us soon. I'll follow up with an email next Tuesday. It's in Springfield.";

export const InputForm: React.FC<InputFormProps> = ({ onAnalyze, isLoading }) => {
  const [inputText, setInputText] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAnalyze(inputText);
  };
  
  const handleSampleClick = (sampleText: string) => {
    setInputText(sampleText);
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
      <form onSubmit={handleSubmit}>
        <label htmlFor="message" className="block text-lg font-semibold text-gray-300 mb-2">
          Salesperson's Message
        </label>
        <p className="text-sm text-gray-400 mb-4">Paste the free-form text message from the salesperson below to extract the details.</p>
        <textarea
          id="message"
          rows={10}
          className="w-full p-3 bg-gray-900 border-2 border-gray-700 rounded-md focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition duration-200 text-gray-200 placeholder-gray-500"
          placeholder="e.g., New referral for Jane Doe from Mercy Hospital..."
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          disabled={isLoading}
        />
        <div className="mt-4 flex flex-col sm:flex-row items-center justify-between">
          <button
            type="submit"
            className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-cyan-600 hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 focus:ring-offset-gray-800 disabled:bg-gray-500 disabled:cursor-not-allowed transition duration-200"
            disabled={isLoading || !inputText.trim()}
          >
            {isLoading ? <Spinner /> : 'Analyze Message'}
          </button>
           <div className="mt-4 sm:mt-0 flex items-center space-x-2">
            <span className="text-sm text-gray-400">Try a sample:</span>
            <button type="button" onClick={() => handleSampleClick(sampleReferral)} className="text-sm text-cyan-400 hover:text-cyan-300 disabled:opacity-50" disabled={isLoading}>Referral</button>
            <span className="text-gray-500">|</span>
            <button type="button" onClick={() => handleSampleClick(sampleActivity)} className="text-sm text-cyan-400 hover:text-cyan-300 disabled:opacity-50" disabled={isLoading}>Activity</button>
          </div>
        </div>
      </form>
      <div className="mt-6 p-4 bg-gray-900/50 border border-gray-700 rounded-lg flex items-start">
        <LightbulbIcon className="h-6 w-6 text-yellow-400 mr-3 flex-shrink-0 mt-1" />
        <div>
            <h4 className="font-semibold text-gray-200">Tip</h4>
            <p className="text-sm text-gray-400">For best results, include as much detail as possible, such as names, locations, services needed, or outcomes of a visit.</p>
        </div>
      </div>
    </div>
  );
};


import React from 'react';

const BrainIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2C9.25 2 7 4.25 7 7c0 1.43.55 2.73 1.46 3.69C7.4 11.53 6.62 12.63 6.2 14H5c-1.1 0-2 .9-2 2v2c0 1.1.9 2 2 2h1v2H5c-1.1 0-2 .9-2 2v1h18v-1c0-1.1-.9-2-2-2h-1v-2h1c1.1 0 2-.9 2-2v-2c0-1.1-.9-2-2-2h-1.2c-.42-1.37-1.2-2.47-2.26-3.31C16.45 9.73 17 8.43 17 7c0-2.75-2.25-5-5-5zm0 2c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zM9 14.23c.59-.83 1.4-1.5 2.37-1.92C11.79 12.56 12 13.25 12 14v6H9v-5.77zM15 20v-6c0-.75.21-1.44.63-2.09.97.42 1.78 1.09 2.37 1.92V20h-3z" />
  </svg>
);


export const Header: React.FC = () => {
  return (
    <header className="bg-gray-800 shadow-md">
      <div className="container mx-auto px-4 md:px-8 py-4 flex items-center justify-center">
        <BrainIcon className="h-8 w-8 text-cyan-400 mr-3" />
        <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight">
          Home Care CRM Assistant
        </h1>
      </div>
    </header>
  );
};

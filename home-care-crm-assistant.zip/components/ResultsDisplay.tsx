
import React from 'react';
import type { CrmResponse, ExtractedData } from '../types';
import { Spinner } from './Spinner';

interface ResultsDisplayProps {
  result: CrmResponse | null;
  isLoading: boolean;
  error: string | null;
  originalInput: string;
}

const ClipboardIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.666 3.888A2.25 2.25 0 0 0 13.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v3.042m-7.332-3.654C6.182 3.998 6 4.468 6 5.25v3.042m3.375 0V11.25a2.25 2.25 0 0 0 2.25 2.25h1.5a2.25 2.25 0 0 0 2.25-2.25V8.292m-9 12.75h9m-9 0a2.25 2.25 0 0 1-2.25-2.25v-9.75a2.25 2.25 0 0 1 2.25-2.25h9.75a2.25 2.25 0 0 1 2.25 2.25v9.75a2.25 2.25 0 0 1-2.25 2.25H9.375Z" />
    </svg>
);

const REFERRAL_KEYS: (keyof ExtractedData)[] = ["Referral Date", "Referral Name", "Lead Stage", "Services Needed", "Contact Name", "City", "Zip Code", "Referral Source", "Referral Contact", "Notes/Comments"];
const ACTIVITY_KEYS: (keyof ExtractedData)[] = ["Activity Date", "Activity Type", "Account/Referral Source", "Contact Name", "City", "Zip Code", "Call Outcome", "Next Steps", "Notes/Comments"];

const ResultItem: React.FC<{ label: string; value?: string }> = ({ label, value }) => {
  const displayValue = value && value.trim() ? value : <span className="text-gray-500">N/A</span>;
  return (
    <div className="py-3 sm:grid sm:grid-cols-3 sm:gap-4">
      <dt className="text-sm font-medium text-gray-400">{label}</dt>
      <dd className="mt-1 text-sm text-gray-200 sm:mt-0 sm:col-span-2 break-words">{displayValue}</dd>
    </div>
  );
};


export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ result, isLoading, error, originalInput }) => {
    
    const [copied, setCopied] = React.useState(false);

    const handleCopy = () => {
        if (result) {
            navigator.clipboard.writeText(JSON.stringify(result, null, 2));
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
    };
    
  if (isLoading) {
    return (
      <div className="bg-gray-800 p-6 rounded-lg shadow-lg h-full flex flex-col items-center justify-center">
        <Spinner />
        <p className="mt-4 text-lg text-gray-300">Analyzing message...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-900/20 border border-red-500 text-red-300 p-6 rounded-lg shadow-lg h-full">
        <h3 className="text-xl font-semibold text-red-200 mb-2">Analysis Failed</h3>
        <p>{error}</p>
      </div>
    );
  }

  if (!result) {
    return (
      <div className="bg-gray-800 p-6 rounded-lg shadow-lg h-full flex flex-col items-center justify-center text-center">
        <h3 className="text-xl font-semibold text-gray-300">Awaiting Analysis</h3>
        <p className="mt-2 text-gray-400">Results will be displayed here once a message is analyzed.</p>
      </div>
    );
  }

  const isReferral = result.type === 'referral';
  const keysToShow = isReferral ? REFERRAL_KEYS : ACTIVITY_KEYS;
  const title = isReferral ? 'New Referral Details' : 'Sales Activity Log';
  const data = result.data;
  
  return (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-bold text-white">{title}</h3>
        <button
            onClick={handleCopy}
            className="flex items-center space-x-2 text-sm text-gray-400 hover:text-white transition"
            title="Copy JSON to clipboard"
        >
            <ClipboardIcon className="h-5 w-5"/>
            <span>{copied ? 'Copied!' : 'Copy JSON'}</span>
        </button>
      </div>
      <dl className="divide-y divide-gray-700">
        {keysToShow.map((key) => (
          <ResultItem key={key} label={key} value={data[key]} />
        ))}
      </dl>
      <div className="mt-6 pt-4 border-t border-gray-700">
         <h4 className="text-sm font-medium text-gray-400">Original Message</h4>
         <p className="mt-2 text-sm text-gray-300 bg-gray-900 p-3 rounded-md whitespace-pre-wrap">{originalInput}</p>
      </div>
    </div>
  );
};

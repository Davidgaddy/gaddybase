import type { CrmResponse } from '../types';

// The URL of your backend server.
// In development, this will be http://localhost:3001
// In production, this should be the public URL of your deployed backend.
const API_BASE_URL = 'http://localhost:3001';

export const extractCrmData = async (userInput: string): Promise<CrmResponse> => {
  try {
    const response = await fetch(`${API_BASE_URL}/api/analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ message: userInput }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      const errorMessage = errorData?.error || `Request failed with status ${response.status}`;
      throw new Error(errorMessage);
    }

    const data: CrmResponse = await response.json();
    return data;

  } catch (err) {
    console.error("Error calling backend service:", err);
    if (err instanceof TypeError) {
      throw new Error("Could not connect to the analysis service. Please ensure the backend server is running.");
    }
    throw err;
  }
};

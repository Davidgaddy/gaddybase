
export interface ExtractedData {
    // Shared fields
    "Contact Name"?: string;
    "City"?: string;
    "Zip Code"?: string;
    "Notes/Comments"?: string;

    // Referral specific fields
    "Referral Date"?: string;
    "Lead Stage"?: string;
    "Services Needed"?: string;
    "Referral Name"?: string;
    "Referral Source"?: string;
    "Referral Contact"?: string;

    // Activity specific fields
    "Activity Date"?: string;
    "Activity Type"?: string;
    "Account/Referral Source"?: string;
    "Call Outcome"?: string;
    "Next Steps"?: string;
}

export interface CrmResponse {
    type: 'referral' | 'activity';
    data: ExtractedData;
}

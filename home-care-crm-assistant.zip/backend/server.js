import express from 'express';
import cors from 'cors';
import 'dotenv/config';
import { GoogleGenAI, Type } from "@google/genai";

const app = express();
const port = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// --- Gemini API Logic ---

// --- Schemas for AI Responses ---

const classificationSchema = {
    type: Type.OBJECT,
    properties: {
        type: { type: Type.STRING, enum: ['referral', 'activity', 'unknown'] }
    },
    required: ['type']
};

const referralSchema = {
    type: Type.OBJECT,
    properties: {
        "Referral Date": { type: Type.STRING, description: "Date of the referral (use today if not specified)." },
        "Lead Stage": { type: Type.STRING, description: `Current stage from the list: "1. Lead/Prospect", "2. Pending Referral", "3. In Clinical Review", "4. Pending Staffing", "5. Pending SOC", "6. Admit", "9. SOC". Default to "1. Lead/Prospect".` },
        "Services Needed": { type: Type.STRING, description: `Services required. Default to "Personal Care".` },
        "Referral Name": { type: Type.STRING, description: "Full name of the client/patient." },
        "Contact Name": { type: Type.STRING, description: "Primary contact person's name (if different from client)." },
        "City": { type: Type.STRING, description: "City of the client." },
        "Zip Code": { type: Type.STRING, description: "Zip code of the client." },
        "Referral Source": { type: Type.STRING, description: "Source of the referral (e.g., hospital, company name)." },
        "Referral Contact": { type: Type.STRING, description: "Name of the individual person who gave the referral." },
        "Notes/Comments": { type: Type.STRING, description: "Any other relevant notes or comments." },
    }
};

const activitySchema = {
    type: Type.OBJECT,
    properties: {
        "Activity Date": { type: Type.STRING, description: "Date activity occurred (use today if not specified)." },
        "Activity Type": { type: Type.STRING, description: `Type from the list: "Email", "Phone Call", "Networking Event", "In-Person Meeting (scheduled)", "Virtual Meeting (scheduled)", "Cold Call", "Routine Drop-In".` },
        "Account/Referral Source": { type: Type.STRING, description: "The facility, company, or account visited or contacted." },
        "Contact Name": { type: Type.STRING, description: "Name of the person met or contacted." },
        "City": { type: Type.STRING, description: "City where the activity took place." },
        "Zip Code": { type: Type.STRING, description: "Zip code where the activity took place." },
        "Call Outcome": { type: Type.STRING, description: "The result or outcome of the activity." },
        "Next Steps": { type: Type.STRING, description: "Planned follow-up actions." },
        "Notes/Comments": { type: Type.STRING, description: "Any other relevant notes or comments." },
    }
};

const getResponse = async (ai, systemInstruction, userInput, schema) => {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: userInput,
        config: {
            systemInstruction,
            responseMimeType: "application/json",
            responseSchema: schema,
            temperature: 0.1,
        }
    });

    const text = response.text;
    try {
        return JSON.parse(text);
    } catch (e) {
        console.error("Failed to parse JSON response from Gemini:", text);
        throw new Error("The AI returned an invalid format.");
    }
};


const extractCrmData = async (userInput) => {
    if (!process.env.API_KEY) {
        throw new Error("API_KEY is not configured in the .env file.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    // --- Step 1: Classify the message type ---
    const classificationInstruction = `You are a text classification agent. Determine if the user's message is about a "New Referral" or a "Sales Activity". Respond only with 'referral', 'activity', or 'unknown'.`;
    const classification = await getResponse(ai, classificationInstruction, userInput, classificationSchema);
    const type = classification.type;

    if (type === 'unknown') {
        return { type: 'unknown', data: { 'Notes/Comments': 'Could not determine if this was a referral or activity.' } };
    }

    // --- Step 2: Extract data based on the classified type ---
    let data;
    if (type === 'referral') {
        const referralInstruction = "You are a CRM data entry assistant. Extract information for a new referral from the user's text based on the provided schema. Default 'Services Needed' to 'Personal Care'. Use today's date if not specified. Do not hallucinate; leave fields blank if information is not present.";
        data = await getResponse(ai, referralInstruction, userInput, referralSchema);
    } else { // type === 'activity'
        const activityInstruction = "You are a CRM data entry assistant. Extract information about a sales activity from the user's text based on the provided schema. Use today's date if not specified. Do not hallucinate; leave fields blank if information is not present.";
        data = await getResponse(ai, activityInstruction, userInput, activitySchema);
    }

    return { type, data };
};


// --- API Endpoints ---

app.get('/', (req, res) => {
    res.send('Home Care CRM Assistant Backend is running.');
});

app.post('/api/analyze', async (req, res) => {
    const { message } = req.body;
    if (!message) {
        return res.status(400).json({ error: 'Message text not found in request body.' });
    }
    try {
        const crmData = await extractCrmData(message);
        res.status(200).json(crmData);
    } catch (error) {
        console.error("Error in /api/analyze:", error.message, error.stack);
        res.status(500).json({ error: 'Failed to process message with the AI model.' });
    }
});

app.post('/api/sms-webhook', async (req, res) => {
    console.log("Webhook received:", JSON.stringify(req.body, null, 2));
    const messageText = req.body.message || req.body.message_text;

    if (!messageText) {
        console.log("Webhook received, but message text was not found.");
        return res.status(400).json({ error: 'Message text not found in request body.' });
    }

    try {
        const crmData = await extractCrmData(messageText);
        console.log("--- Successfully Extracted CRM Data from Webhook ---");
        console.log(JSON.stringify(crmData, null, 2));
        res.status(200).json({ success: true, data: crmData });
    } catch (error) {
        console.error("Error processing webhook message:", error.message);
        res.status(500).json({ error: 'Failed to process webhook message.' });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server listening on http://localhost:${port}`);
});

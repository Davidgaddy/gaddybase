
# Home Care CRM Assistant - Backend Server

This directory contains a Node.js server that acts as a webhook receiver for incoming SMS messages from a service like Captivated. It extracts the message content, uses the Google Gemini API to parse it into structured CRM data, and logs the result.

## How to Use

### Step 1: Installation

First, you need to install Node.js on your system if you haven't already. Then, open your terminal in this `backend` directory and install the required dependencies.

```bash
# Navigate to the backend directory
cd backend

# Install dependencies
npm install
```

### Step 2: Configure API Key

The server needs your Google Gemini API key to function.

1.  Rename the `.env.example` file to `.env`.
2.  Open the new `.env` file and paste your API key into it.

**File: `.env`**
```
# This is a secret file. Do not commit it to version control.
API_KEY="YOUR_GEMINI_API_KEY_HERE"
```

### Step 3: Run the Server

You can now start the server from your terminal.

```bash
npm start
```

If successful, you will see the following message:
`Server listening on http://localhost:3001`

The server is now running locally and waiting for requests.

### Step 4: Test the Server

Before you connect Captivated, you can test the server to make sure it's working. You can use a command-line tool like `curl` or a desktop API client like Postman.

**Using `curl` in a new terminal window:**

```bash
curl -X POST http://localhost:3001/api/sms-webhook \
-H "Content-Type: application/json" \
-d '{
  "message": "New referral from St. Josephs hospital. Patient is John Smith, needs skilled nursing. He lives in Anytown, 90210. His daughter Jane Doe is the main contact."
}'
```

Check the terminal window where your server is running. You should see the extracted JSON data printed to the console.

### Step 5: Connect to Captivated

1.  **Expose your server to the internet.** Services like Captivated cannot send webhooks to `localhost`. You will need to deploy this server to a cloud provider (like Google Cloud Run, Vercel, Heroku) or use a tunneling service like [ngrok](https://ngrok.com/) during development to get a public URL.

2.  **Configure the Webhook in Captivated.** Log in to your Captivated account, find the developer/API settings, and configure a webhook for incoming messages. Set the webhook URL to your public server address (e.g., `https://your-public-app-url.com/api/sms-webhook`).

3.  **Adapt the Code for Captivated's Payload.** The current code in `server.js` assumes the incoming message is in a simple format: `{ "message": "..." }`. You **must** check Captivated's developer documentation to see the actual JSON format they send and update this line in `server.js` accordingly:
    ```javascript
    const messageText = req.body.message; // Change req.body.message
    ```
    For example, if Captivated sends `{ "message_text": "...", "from_number": "..." }`, you would change it to `const messageText = req.body.message_text;`.


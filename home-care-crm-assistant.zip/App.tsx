import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { InputForm } from './components/InputForm';
import { ResultsDisplay } from './components/ResultsDisplay';
import { extractCrmData } from './services/geminiService';
import type { CrmResponse } from './types';

const App: React.FC = () => {
  const [result, setResult] = useState<CrmResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [currentInput, setCurrentInput] = useState<string>('');

  const handleAnalyze = useCallback(async (inputText: string) => {
    if (!inputText.trim()) {
      setError("Please enter a message to analyze.");
      return;
    }
    
    setIsLoading(true);
    setError(null);
    setResult(null);
    setCurrentInput(inputText);

    try {
      const extractedData = await extractCrmData(inputText);
      setResult(extractedData);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "An unknown error occurred.";
      console.error("Error during analysis:", errorMessage);
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 font-sans">
      <Header />
      <main className="container mx-auto p-4 md:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          <InputForm onAnalyze={handleAnalyze} isLoading={isLoading} />
          <ResultsDisplay 
            result={result} 
            isLoading={isLoading} 
            error={error} 
            originalInput={currentInput}
          />
        </div>
      </main>
      <footer className="text-center p-4 text-gray-500 text-sm">
        <p>Powered by Google Gemini</p>
      </footer>
    </div>
  );
};

export default App;